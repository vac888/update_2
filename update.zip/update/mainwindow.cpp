#include "mainwindow.h"
#include "ui_mainwindow.h"


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_3_clicked()
{
    const char* batFilePath = "C:/Users/LLLLL/Documents/download_2/test.bat";
    int result = system(batFilePath);

    if (result == 0) {
        qDebug() << "Файл .bat успешно запущен.";
    } else {
        qDebug() << "Ошибка при запуске файла .bat.";
    }
}

